﻿using PR22106BorovkovaWPF.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PR22106BorovkovaWPF
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            frame.Content = new Pages.PageMain();
        }
        public class helper
        {
            public static PR22106BorovkovaEntities ent;
            public static PR22106BorovkovaEntities GetContext()
            {
                if (ent == null)
                {
                    ent = new PR22106BorovkovaEntities();
                }
                return ent;
            }
        }
    }
}
